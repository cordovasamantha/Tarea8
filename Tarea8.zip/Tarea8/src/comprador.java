public interface comprador {
    boolean menorQue(Object q);
    boolean mayorQue(Object q);
    boolean menorIgualQue(Object q);
    boolean mayorIgualQue(Object q);
    boolean igualque(Object q);
}
