
public class Test {
    public static void main(String[] args) throws Exception {
        producto p = new producto();
        alumno a = new alumno();
        alumno a1 = new alumno(18, "16 896", "Josue");
        boolean al = a.mayorIgualQue(a1);
        boolean alu = a.menorIgualQue(a1);
        boolean alum = a.mayorQue(a1);
        boolean alumn = a.menorQue(a1);
        boolean alumno = a.igualque(a1);
        System.out.println(al);
        System.out.println(alu);
        System.out.println(alum);
        System.out.println(alumn);
        System.out.println(alumno);

        producto p1 = new producto(123, "Mermelada Helios", 25.75);
        boolean pr = p.mayorIgualQue(p1);
        boolean pro = p.menorIgualQue(p1);
        boolean prod = p.mayorQue(p1);
        boolean produ = p.menorQue(p1);
        boolean produc = p.igualque(p1);
        System.out.println(pr);
        System.out.println(pro);
        System.out.println(prod);
        System.out.println(produ);
        System.out.println(produc);

    }
}
