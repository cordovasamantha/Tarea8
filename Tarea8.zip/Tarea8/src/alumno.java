public class alumno implements comprador {
    public int iEdad;
    private String sCarne;
    private String sNombre;

    public alumno() {
    }

    public alumno(int iEdad, String sCarne, String sNombre) {
        this.iEdad = iEdad;
        this.sCarne = sCarne;
        this.sNombre = sNombre;
    }
    
    @Override
    public boolean menorQue(Object q) {
        alumno a = (alumno)q;
        return this.iEdad < a.iEdad;
    }

    @Override
    public boolean mayorQue(Object q) {
        alumno a = (alumno)q;
        return this.iEdad > a.iEdad;
    }

    @Override
    public boolean menorIgualQue(Object q) {
        alumno a = (alumno)q;
        return this.iEdad <= a.iEdad;
    }

    @Override
    public boolean mayorIgualQue(Object q) {
        alumno a = (alumno)q;
        return this.iEdad >= a.iEdad;
    }

    @Override
    public boolean igualque(Object q) {
        alumno a = (alumno)q;
        return this.iEdad == a.iEdad;
    }

}
