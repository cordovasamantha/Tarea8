public class producto implements comprador {
    private int iId;
    private String sNombre;
    private double dPrecio;

    public producto() {
    }

    public producto(int iId, String sNombre, double dPrecio) {
        this.iId = iId;
        this.sNombre = sNombre;
        this.dPrecio = dPrecio;    }

    @Override
    public boolean menorQue(Object q) {
        producto p = (producto)q;
        return this.dPrecio < p.dPrecio;
    }

    @Override
    public boolean mayorQue(Object q) {
        producto p = (producto)q;
        return this.dPrecio > p.dPrecio;
    }

    @Override
    public boolean menorIgualQue(Object q) {
        producto p = (producto)q; 
        return this.dPrecio <= p.dPrecio;
    }

    @Override
    public boolean mayorIgualQue(Object q) {
        producto p = (producto)q;
        return this.dPrecio >= p.dPrecio;
    }

    @Override
    public boolean igualque(Object q) {
        producto p = (producto)q;
        return this.dPrecio == p.dPrecio;
    }

}